/*
Navicat MySQL Data Transfer

Source Server         : MySQL_JF
Source Server Version : 50529
Source Host           : localhost:3306
Source Database       : mdb

Target Server Type    : MYSQL
Target Server Version : 50529
File Encoding         : 65001

Date: 2017-11-20 20:11:35
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `history`
-- ----------------------------
DROP TABLE IF EXISTS `history`;
CREATE TABLE `history` (
  `uid` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号(自动增长)',
  `ID` int(11) NOT NULL COMMENT '站号',
  `opening` double NOT NULL COMMENT '开度',
  `flow` double NOT NULL COMMENT '流量',
  `upstream` double NOT NULL COMMENT '上游水位',
  `downstream` double NOT NULL COMMENT '下游水位',
  `locklimit` int(11) NOT NULL COMMENT '限位\r\n无限位：0\r\n上限位：1\r\n下限位：2',
  `dam_state` int(11) NOT NULL COMMENT '水闸状态\r\n正在开启：1\r\n已停止：2\r\n正在关闭：3',
  `motor_state` int(11) NOT NULL COMMENT '电机状态\r\n正常：0\r\n通讯错误：1\r\n数据错误：2\r\n运行错误：3',
  `timestamp` varchar(255) NOT NULL COMMENT '更新时间',
  `opcode` int(20) NOT NULL COMMENT '操作码\r\n现场设置开度：0\r\n现场设置流量：1\r\n现场启动闸门：2\r\n现场关闭闸门：3\r\n现场停止闸门：4\r\n现场无操作：7、8、9\r\nWEB设置开度：2000\r\nWEB设置流量：2001\r\nWEB启动闸门：2002\r\nWEB关闭闸门：2003\r\nWEB停止闸门：2004\r\n安卓设置开度：1000\r\n安卓设置流量：1001\r\n安卓开启闸门：1002\r\n安卓关闭闸门：1003\r\n安卓停止闸门：1004',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=689 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of history
-- ----------------------------
INSERT INTO `history` VALUES ('1', '1', '12.32', '12.32', '5.22', '2.32', '1', '3', '0', '2017/03/22 18:00', '2');
INSERT INTO `history` VALUES ('2', '2', '12.23', '23.23', '12.22', '1.23', '2', '3', '2', '2017/03/22 19:00', '3');
INSERT INTO `history` VALUES ('3', '3', '12.26', '12.62', '56.62', '43.23', '1', '1', '0', '2017/03/23 05:12:62', '1001');
INSERT INTO `history` VALUES ('4', '4', '26.23', '26.45', '56.12', '25.26', '2', '2', '3', '2017/03/23 05:23:15', '0');
INSERT INTO `history` VALUES ('5', '5', '15.16', '12.62', '26.16', '23.15', '0', '1', '0', '2017/03/23 06:26:26', '4');
INSERT INTO `history` VALUES ('6', '6', '26.23', '26.16', '23.23', '21.23', '0', '2', '1', '2017/03/23 06:52:23', '1000');
INSERT INTO `history` VALUES ('7', '5', '65.26', '5.26', '15.26', '6.51', '2', '3', '0', '2017/03/23 06:59:23', '1');
INSERT INTO `history` VALUES ('8', '5', '21.13', '5.62', '12.23', '21.26', '0', '1', '0', '2017/03/23 07:54:15', '0');
INSERT INTO `history` VALUES ('9', '4', '23.26', '23.63', '23.23', '12.32', '1', '2', '1', '2017/03/24 05:26:23', '2');
INSERT INTO `history` VALUES ('10', '5', '12.26', '23.23', '15.26', '23.26', '0', '1', '1', '2017/03/24 06:23:23', '1');
INSERT INTO `history` VALUES ('11', '6', '12.2', '41.23', '12.23', '23.22', '2', '1', '0', '2017/03/25 07:25:21', '8');
INSERT INTO `history` VALUES ('12', '1', '23.23', '15.23', '12.23', '1.23', '2', '2', '1', '2017/03/25 08:15:12', '7');
INSERT INTO `history` VALUES ('13', '2', '12.23', '12.65', '25.15', '52.23', '0', '3', '0', '2017/03/25 09:29:23', '9');
INSERT INTO `history` VALUES ('14', '5', '25.23', '12.23', '21.23', '12.23', '1', '1', '1', '2017/03/25 10:10:26', '2000');
INSERT INTO `history` VALUES ('15', '2', '2.26', '23.23', '12.45', '21.95', '1', '3', '0', '2017/03/25 11:25:23', '1002');
INSERT INTO `history` VALUES ('16', '2', '23.23', '12.23', '12.59', '23.26', '1', '1', '3', '2017/03/25 11:45:25', '1003');
INSERT INTO `history` VALUES ('17', '2', '23.23', '12.26', '12.59', '23.33', '2', '2', '0', '2017/03/26 12:25:23', '1004');
INSERT INTO `history` VALUES ('18', '1', '26.65', '15.62', '15.23', '13.62', '0', '2', '2', '2017/03/27 12:12:23', '2001');
INSERT INTO `history` VALUES ('19', '2', '2.62', '23.23', '12.58', '41.23', '2', '3', '0', '2017/03/27 12:23:23', '2002');
INSERT INTO `history` VALUES ('20', '6', '23.23', '41.45', '89.23', '12.45', '0', '1', '1', '2017/03/27 13:23:13', '2003');
INSERT INTO `history` VALUES ('21', '2', '32.23', '12.12', '21.23', '12.56', '0', '1', '0', '2017/03/28 13:23:26', '2004');
INSERT INTO `history` VALUES ('653', '1', '45.432', '1.234', '30.423', '11.049', '2', '2', '2', '2017/10/04 00:25:54', '2');
INSERT INTO `history` VALUES ('654', '1', '46.534', '2.321', '20.432', '10.994', '2', '2', '2', '2017/10/04 00:25:55', '2');
INSERT INTO `history` VALUES ('655', '1', '47.543', '3.231', '34.324', '7.045', '2', '2', '2', '2017/10/04 00:25:56', '2');
INSERT INTO `history` VALUES ('656', '1', '48.432', '4.321', '44.324', '9.083', '2', '2', '2', '2017/10/04 00:25:57', '2');
INSERT INTO `history` VALUES ('657', '1', '49.432', '1.234', '43.542', '5.134', '2', '2', '2', '2017/10/04 00:25:58', '2');
INSERT INTO `history` VALUES ('658', '1', '12.432', '2.321', '12.653', '5.865', '2', '2', '2', '2017/10/04 00:26:00', '2');
INSERT INTO `history` VALUES ('659', '1', '8.176', '3.432', '23.323', '23.543', '2', '2', '2', '2017/10/04 00:26:01', '2');
INSERT INTO `history` VALUES ('660', '1', '14.227', '4.323', '45.342', '14.234', '2', '2', '2', '2017/10/04 00:26:02', '2');
INSERT INTO `history` VALUES ('661', '1', '6.265', '1.234', '34.456', '12.345', '2', '2', '2', '2017/10/04 00:26:03', '2');
INSERT INTO `history` VALUES ('662', '1', '12.316', '2.321', '34.456', '34.222', '2', '2', '2', '2017/10/04 00:26:04', '2');
INSERT INTO `history` VALUES ('663', '1', '11.301', '3.432', '34.456', '34.543', '2', '2', '2', '2017/10/04 00:26:05', '2');
INSERT INTO `history` VALUES ('664', '1', '13.339', '4.432', '34.456', '23.432', '2', '2', '2', '2017/10/04 00:26:06', '2');
INSERT INTO `history` VALUES ('665', '1', '23.456', '2.321', '34.456', '25.543', '2', '2', '2', '2017/10/04 00:26:07', '2');
INSERT INTO `history` VALUES ('666', '1', '24.345', '4.432', '34.456', '27.234', '2', '2', '2', '2017/10/04 00:26:08', '2');
INSERT INTO `history` VALUES ('667', '1', '25.453', '2.432', '34.456', '28.345', '2', '2', '2', '2017/10/04 00:26:09', '2');
INSERT INTO `history` VALUES ('668', '1', '26.453', '3.432', '34.456', '29.123', '2', '2', '2', '2017/10/04 00:26:10', '2');
INSERT INTO `history` VALUES ('669', '1', '27.543', '3.321', '9.414', '30.432', '2', '2', '2', '2017/10/04 00:26:11', '2');
INSERT INTO `history` VALUES ('670', '1', '28.344', '3.432', '9.414', '31.543', '2', '2', '2', '2017/10/04 00:26:12', '2');
INSERT INTO `history` VALUES ('671', '1', '29.432', '3.432', '9.414', '32.654', '2', '2', '2', '2017/10/04 00:26:13', '2');
INSERT INTO `history` VALUES ('672', '1', '30.321', '1.234', '11.453', '23.543', '2', '2', '2', '2017/10/04 00:26:14', '2');
INSERT INTO `history` VALUES ('673', '1', '31.234', '4.321', '7.503', '32.543', '2', '2', '2', '2017/10/04 00:26:15', '2');
INSERT INTO `history` VALUES ('674', '1', '32.432', '1.234', '13.554', '34.543', '2', '2', '2', '2017/11/18 00:26:16', '2');
INSERT INTO `history` VALUES ('675', '1', '33.432', '3.435', '12.539', '45.432', '2', '2', '2', '2017/11/18 00:26:17', '2');
INSERT INTO `history` VALUES ('676', '1', '34.432', '4.876', '14.577', '47.432', '2', '2', '2', '2017/11/18 00:26:18', '2');
INSERT INTO `history` VALUES ('677', '1', '13.753', '4.654', '23.456', '37.432', '2', '2', '2', '2017/11/18 00:26:19', '2');
INSERT INTO `history` VALUES ('678', '1', '9.804', '2.654', '33.234', '35.654', '2', '2', '2', '2017/11/18 00:26:20', '2');
INSERT INTO `history` VALUES ('679', '1', '8.99', '1.654', '34.654', '39.432', '2', '2', '2', '2017/11/18 00:26:21', '2');
INSERT INTO `history` VALUES ('680', '1', '5.882', '3.654', '25.435', '40.543', '2', '2', '2', '2017/11/18 00:26:22', '2');
INSERT INTO `history` VALUES ('681', '1', '10.075', '2.543', '11.33', '42.654', '2', '2', '2', '2017/11/18 00:26:23', '2');
INSERT INTO `history` VALUES ('682', '1', '10.98', '3.654', '43.564', '45.564', '2', '2', '2', '2017/11/18 00:26:24', '2');
INSERT INTO `history` VALUES ('683', '1', '11.034', '4.765', '25.654', '34.654', '2', '2', '2', '2017/11/18 00:26:25', '2');
INSERT INTO `history` VALUES ('684', '1', '10.979', '3.543', '34.543', '45.234', '2', '2', '2', '2017/11/18 00:26:26', '2');
INSERT INTO `history` VALUES ('685', '1', '14.263', '2.654', '41.342', '43.543', '2', '2', '2', '2017/11/18 00:26:27', '2');
INSERT INTO `history` VALUES ('686', '1', '8.221', '3.454', '42.323', '34.432', '2', '2', '2', '2017/11/18 00:26:28', '2');
INSERT INTO `history` VALUES ('687', '1', '8.221', '2.345', '23.333', '35.321', '2', '2', '2', '2017/11/18 00:26:29', '2');
INSERT INTO `history` VALUES ('688', '1', '11.221', '3.543', '34.543', '45.543', '2', '2', '2', '2017/11/18 00:26:30', '2');

-- ----------------------------
-- Table structure for `irrigated`
-- ----------------------------
DROP TABLE IF EXISTS `irrigated`;
CREATE TABLE `irrigated` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '灌区编号',
  `irrname` varchar(255) NOT NULL COMMENT '灌区名称',
  `irrplace` varchar(255) NOT NULL COMMENT '灌区地址',
  `survey` varchar(255) DEFAULT NULL COMMENT '灌区概况',
  `distriimg` varchar(255) DEFAULT NULL COMMENT '闸站分布图',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of irrigated
-- ----------------------------
INSERT INTO `irrigated` VALUES ('1', '水利水电模拟灌区', '浙江水利水电', '杭州大工程', '分布图');
INSERT INTO `irrigated` VALUES ('2', '钱塘江灌区', '钱塘江', '钱塘江灌区工程项目建立多年，效果突出', '分布图');
INSERT INTO `irrigated` VALUES ('3', '乌溪江引水工程', '乌溪江', '乌溪江引水工程，规模浩大', '分布图');
INSERT INTO `irrigated` VALUES ('4', '金坑岭水库灌区', '金坑岭', '金坑岭灌区工程量大，人力投入多', '分布图');
INSERT INTO `irrigated` VALUES ('5', '曹娥江灌区工程', '上虞', '钱塘江灌区工程耗资巨大', '分布图');
INSERT INTO `irrigated` VALUES ('6', '千岛湖灌区工程', '千岛湖', '杭州千岛湖灌区工程是近年来最大的项目之一', '分布图');
INSERT INTO `irrigated` VALUES ('7', '昆仑山灌区', '昆仑山', '耗资巨大', '分布图');
INSERT INTO `irrigated` VALUES ('8', '天山灌区', '天山', '耗资巨大', '分布图');

-- ----------------------------
-- Table structure for `mito`
-- ----------------------------
DROP TABLE IF EXISTS `mito`;
CREATE TABLE `mito` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '水户编号',
  `fullname` varchar(255) NOT NULL COMMENT '水户名称',
  `area` varchar(255) DEFAULT NULL COMMENT '农田面积',
  `croptype` varchar(255) DEFAULT NULL COMMENT '作物种类',
  `place` varchar(255) DEFAULT NULL COMMENT '农田地址',
  `sluiceid` int(11) NOT NULL COMMENT '配水闸站',
  `tel` varchar(255) NOT NULL COMMENT '电话',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mito
-- ----------------------------
INSERT INTO `mito` VALUES ('1', '老王', '200', '玉米', '杭州下沙', '1', '13856412365');
INSERT INTO `mito` VALUES ('2', '老郑', '150', '黄豆', '杭州滨江', '2', '15965412963');

-- ----------------------------
-- Table structure for `operatelog`
-- ----------------------------
DROP TABLE IF EXISTS `operatelog`;
CREATE TABLE `operatelog` (
  `username` varchar(255) NOT NULL COMMENT '用户名',
  `opcode` int(11) NOT NULL COMMENT '操作码\r\n现场设置开度：0\r\n现场设置流量：1\r\n现场启动闸门：2\r\n现场关闭闸门：3\r\n现场停止闸门：4\r\n现场无操作：7、8、9\r\nWEB设置开度：2000\r\nWEB设置流量：2001\r\nWEB启动闸门：2002\r\nWEB关闭闸门：2003\r\nWEB停止闸门：2004\r\n安卓设置开度：1000\r\n安卓设置流量：1001\r\n安卓开启闸门：1002\r\n安卓关闭闸门：1003\r\n安卓停止闸门：1004',
  `operatetime` varchar(255) NOT NULL COMMENT '操作时间',
  `ipaddr` varchar(255) NOT NULL COMMENT '源地址'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of operatelog
-- ----------------------------
INSERT INTO `operatelog` VALUES ('mcu', '4', '2017/11/06 20:34:27', '112.17.243.218:10856');
INSERT INTO `operatelog` VALUES ('mcu', '4', '2017/11/06 20:37:58', '112.17.245.207:38820');
INSERT INTO `operatelog` VALUES ('mcu', '4', '2017/11/06 20:42:25', '112.17.245.207:38820');
INSERT INTO `operatelog` VALUES ('mcu', '4', '2017/11/06 22:03:45', '112.17.243.10:49290');
INSERT INTO `operatelog` VALUES ('mcu', '4', '2017/11/06 22:23:29', '112.17.244.99:55518');
INSERT INTO `operatelog` VALUES ('storm', '1', '2017/11/06 23:43:43', 'API');
INSERT INTO `operatelog` VALUES ('storm', '1', '2017/11/06 23:44:15', 'API');
INSERT INTO `operatelog` VALUES ('storm', '1', '2017/11/07 00:10:45', 'API');
INSERT INTO `operatelog` VALUES ('storm', '1', '2017/11/07 00:11:10', 'API');
INSERT INTO `operatelog` VALUES ('storm', '1', '2017/11/07 00:12:50', 'API');
INSERT INTO `operatelog` VALUES ('storm', '1', '2017/11/07 00:16:50', 'API');
INSERT INTO `operatelog` VALUES ('fangjiaming', '2', '2017/11/07 00:17:06', 'API');
INSERT INTO `operatelog` VALUES ('fangjiaming', '3', '2017/11/07 00:17:39', 'API');
INSERT INTO `operatelog` VALUES ('fangjiaming', '2', '2017/11/07 00:18:33', 'API');
INSERT INTO `operatelog` VALUES ('fangjiaming', '2', '2017/11/07 00:19:05', 'API');
INSERT INTO `operatelog` VALUES ('fangjiaming', '1', '2017/11/07 00:19:43', 'API');
INSERT INTO `operatelog` VALUES ('fangjiaming', '3', '2017/11/07 00:21:44', 'API');
INSERT INTO `operatelog` VALUES ('storm', '2', '2017/11/07 00:23:18', 'API');
INSERT INTO `operatelog` VALUES ('storm', '1', '2017/11/07 00:24:53', 'API');
INSERT INTO `operatelog` VALUES ('storm', '1', '2017/11/07 00:25:09', 'API');
INSERT INTO `operatelog` VALUES ('storm', '2', '2017/11/07 00:26:14', 'API');
INSERT INTO `operatelog` VALUES ('storm', '1', '2017/11/07 00:27:42', 'API');
INSERT INTO `operatelog` VALUES ('storm', '2', '2017/11/07 00:28:12', 'API');
INSERT INTO `operatelog` VALUES ('jeffrey', '2', '2017/11/07 00:28:13', 'WEB');
INSERT INTO `operatelog` VALUES ('jeffrey', '3', '2017/11/07 00:28:39', 'WEB');
INSERT INTO `operatelog` VALUES ('jeffrey', '0', '2017/11/07 00:32:34', 'WEB');
INSERT INTO `operatelog` VALUES ('storm', '1', '2017/11/07 00:32:55', 'WEB');
INSERT INTO `operatelog` VALUES ('storm', '2', '2017/11/07 00:33:21', 'WEB');
INSERT INTO `operatelog` VALUES ('storm', '3', '2017/11/07 00:33:39', 'WEB');
INSERT INTO `operatelog` VALUES ('storm', '4', '2017/11/07 00:33:53', 'WEB');
INSERT INTO `operatelog` VALUES ('storm', '1', '2017/11/07 00:43:01', 'API');
INSERT INTO `operatelog` VALUES ('storm', '0', '2017/11/07 00:43:15', 'API');
INSERT INTO `operatelog` VALUES ('storm', '2', '2017/11/07 00:43:25', 'API');
INSERT INTO `operatelog` VALUES ('storm', '1', '2017/11/07 00:48:53', 'API');
INSERT INTO `operatelog` VALUES ('storm', '1', '2017/11/07 00:49:49', 'API');
INSERT INTO `operatelog` VALUES ('fangjiaming', '1', '2017/11/07 00:50:08', 'API');
INSERT INTO `operatelog` VALUES ('fangjiaming', '0', '2017/11/07 00:50:22', 'API');
INSERT INTO `operatelog` VALUES ('storm', '0', '2017/11/07 00:50:52', 'API');
INSERT INTO `operatelog` VALUES ('storm', '1', '2017/11/07 00:51:45', 'API');
INSERT INTO `operatelog` VALUES ('fangjiaming', '0', '2017/11/07 00:52:25', 'API');
INSERT INTO `operatelog` VALUES ('fangjiaming', '0', '2017/11/07 00:54:09', 'API');
INSERT INTO `operatelog` VALUES ('storm', '0', '2017/11/07 01:00:39', 'API');

-- ----------------------------
-- Table structure for `realtimestatus`
-- ----------------------------
DROP TABLE IF EXISTS `realtimestatus`;
CREATE TABLE `realtimestatus` (
  `ID` int(11) NOT NULL COMMENT '站号',
  `opening` double DEFAULT NULL COMMENT '开度',
  `flow` double DEFAULT NULL COMMENT '流量',
  `upstream` double DEFAULT NULL COMMENT '上游水位',
  `downstream` double DEFAULT NULL COMMENT '下游水位',
  `locklimit` int(11) DEFAULT NULL COMMENT '限位\r\n无限位：0\r\n上限位：1\r\n下限位：2',
  `dam_state` int(11) DEFAULT NULL COMMENT '水闸状态\r\n正在开启：1\r\n已停止：2\r\n正在关闭：3',
  `motor_state` int(11) DEFAULT NULL COMMENT '电机状态\r\n正常：0\r\n通讯错误：1\r\n数据错误：2\r\n运行错误：3',
  `opcode` int(11) DEFAULT NULL COMMENT '操作码\r\n现场设置开度：0\r\n现场设置流量：1\r\n现场启动闸门：2\r\n现场关闭闸门：3\r\n现场停止闸门：4\r\n现场无操作：7、8、9\r\nWEB设置开度：2000\r\nWEB设置流量：2001\r\nWEB启动闸门：2002\r\nWEB关闭闸门：2003\r\nWEB停止闸门：2004\r\n安卓设置开度：1000\r\n安卓设置流量：1001\r\n安卓开启闸门：1002\r\n安卓关闭闸门：1003\r\n安卓停止闸门：1004'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of realtimestatus
-- ----------------------------
INSERT INTO `realtimestatus` VALUES ('1', '315.8', '0.659', '425.3', '269.2', '1', '2', '0', '1001');
INSERT INTO `realtimestatus` VALUES ('2', '256.8', '0.489', '236.6', '153.2', '2', '1', '1', '2002');
INSERT INTO `realtimestatus` VALUES ('3', '109.6', '0.931', '352.3', '253.1', '0', '3', '2', '1000');
INSERT INTO `realtimestatus` VALUES ('4', '98.7', '0.159', '158.6', '82.5', '2', '1', '0', '2');
INSERT INTO `realtimestatus` VALUES ('5', '392.6', '0.953', '702.3', '620', '1', '1', '1', '2000');
INSERT INTO `realtimestatus` VALUES ('6', '156.8', '1.035', '520.3', '321.7', '1', '2', '0', '2002');

-- ----------------------------
-- Table structure for `sluice`
-- ----------------------------
DROP TABLE IF EXISTS `sluice`;
CREATE TABLE `sluice` (
  `ID` int(11) NOT NULL COMMENT '闸站ID',
  `irrid` int(11) NOT NULL COMMENT '所属灌区ID',
  `sluicename` varchar(255) NOT NULL COMMENT '闸站名称',
  `width` double DEFAULT NULL COMMENT '宽度',
  `height` double DEFAULT NULL COMMENT '高度',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sluice
-- ----------------------------
INSERT INTO `sluice` VALUES ('1', '1', 'G0-01', '15.32', '12.33');
INSERT INTO `sluice` VALUES ('2', '1', 'G0-02', '15.95', '21.26');
INSERT INTO `sluice` VALUES ('3', '1', 'G0-23', '15.66', '14.33');
INSERT INTO `sluice` VALUES ('4', '2', 'G1-01', '15.69', '23.51');
INSERT INTO `sluice` VALUES ('5', '2', 'G1-02', '15.95', '14.33');
INSERT INTO `sluice` VALUES ('6', '2', 'G1-03', '15.99', '17.66');
INSERT INTO `sluice` VALUES ('7', '3', 'G2-01', '15.37', '15.32');
INSERT INTO `sluice` VALUES ('8', '3', 'G2-02', '15.11', '14.22');
INSERT INTO `sluice` VALUES ('9', '3', 'G2-03', '19.32', '12.21');
INSERT INTO `sluice` VALUES ('10', '4', 'G3-01', '25.22', '12.14');
INSERT INTO `sluice` VALUES ('11', '4', 'G3-02', '12.23', '15.69');
INSERT INTO `sluice` VALUES ('12', '5', 'G4-01', '26.66', '18.22');
INSERT INTO `sluice` VALUES ('13', '5', 'G4-02', '23.69', '14.69');

-- ----------------------------
-- Table structure for `transfer`
-- ----------------------------
DROP TABLE IF EXISTS `transfer`;
CREATE TABLE `transfer` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '水票号',
  `mitoname` varchar(255) NOT NULL COMMENT '水户姓名',
  `sluiceid` int(11) NOT NULL COMMENT '水闸编号',
  `starttime` varchar(255) NOT NULL COMMENT '开始输水时间',
  `endtime` varchar(255) NOT NULL COMMENT '结束输水时间',
  `howlong` varchar(255) NOT NULL COMMENT '时长',
  `orderwater` double NOT NULL COMMENT '订水量',
  `actualwater` double NOT NULL COMMENT '实际输水量',
  `completion` varchar(255) NOT NULL COMMENT '完成度',
  `datatime` varchar(255) NOT NULL COMMENT '登记时间',
  `sysuser` varchar(255) NOT NULL COMMENT '系统用户',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of transfer
-- ----------------------------
INSERT INTO `transfer` VALUES ('1', '老王', '1', '2017/11/13 20:15:32', '2017/11/13 20:45:20', '20', '192.23', '192.23', '100', '2017/11/13 20:15:32', 'jeffrey');
INSERT INTO `transfer` VALUES ('2', '老郑', '2', '2017/11/13 20:15:32', '2017/11/13 20:15:35', '12', '155.36', '145.32', '85', '2017/11/13 20:15:32', 'jeffrey');
INSERT INTO `transfer` VALUES ('3', '杨文', '3', '2017/11/17 12:00:00', '2017/11/17 13:00:00', '17', '150', '150', '79', '2017/11/17 20:00:25', 'jeffrey');
INSERT INTO `transfer` VALUES ('4', '王凯', '4', '2017/11/18 11:00:15', '2017/11/18 12:25:00', '23', '150', '140', '45', '2017/11/18 20:00:00', 'admin');
INSERT INTO `transfer` VALUES ('5', '王军', '5', '2017/11/18 10:12:25', '2017/11/18 21:00:00', '15', '120', '100', '38', '2017/11/18 20:12:65', 'jeffrey');

-- ----------------------------
-- Table structure for `users`
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户ID(自动增长)',
  `username` varchar(255) NOT NULL COMMENT '用户名',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `apikey` varchar(255) DEFAULT NULL COMMENT '安卓api',
  `expire` varchar(255) DEFAULT NULL COMMENT '安卓操作',
  `fullname` varchar(255) NOT NULL COMMENT '名称',
  `department` varchar(255) NOT NULL COMMENT '部门',
  `tel` varchar(255) NOT NULL COMMENT '电话',
  `email` varchar(255) NOT NULL COMMENT '邮箱',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', 'jeffrey', '123123', null, null, '叶杰锋', '新媒体', '1777777777', 'jeffrey@163.com');

-- ----------------------------
-- Table structure for `webbuffer`
-- ----------------------------
DROP TABLE IF EXISTS `webbuffer`;
CREATE TABLE `webbuffer` (
  `opcode` int(11) NOT NULL COMMENT '操作码\r\n现场设置开度：0\r\n现场设置流量：1\r\n现场启动闸门：2\r\n现场关闭闸门：3\r\n现场停止闸门：4\r\n现场无操作：7、8、9\r\nWEB设置开度：2000\r\nWEB设置流量：2001\r\nWEB启动闸门：2002\r\nWEB关闭闸门：2003\r\nWEB停止闸门：2004\r\n安卓设置开度：1000\r\n安卓设置流量：1001\r\n安卓开启闸门：1002\r\n安卓关闭闸门：1003\r\n安卓停止闸门：1004',
  `ID` int(11) NOT NULL COMMENT '站号',
  `value` double NOT NULL DEFAULT '0' COMMENT '值',
  `username` varchar(255) NOT NULL COMMENT '用户名'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of webbuffer
-- ----------------------------
INSERT INTO `webbuffer` VALUES ('0', '4', '45', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('1', '5', '45', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('0', '1', '13', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('1', '5', '12', 'admin');
INSERT INTO `webbuffer` VALUES ('0', '3', '3.33', 'admin');
INSERT INTO `webbuffer` VALUES ('0', '1', '1', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('1', '2', '23.23', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2001', '2', '23', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '2', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '5', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2001', '3', '2.32', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '6', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2001', '4', '13.13', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '6', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2004', '3', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2001', '6', '12.12', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '6', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2004', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2000', '1', '666', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2001', '1', '666', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2004', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2004', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2004', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2004', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '2', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2004', '5', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '3', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2004', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '6', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '6', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2004', '6', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '2', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2000', '1', '153.3', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2001', '1', '265.3', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2001', '1', '153.9', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2000', '3', '231.3', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2004', '3', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2000', '1', '145.3', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2001', '1', '152.3', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2000', '1', '213', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2001', '1', '12', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2000', '3', '21', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2004', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '4', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2002', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2003', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2004', '1', '0', 'jeffrey');
INSERT INTO `webbuffer` VALUES ('2000', '5', '324', 'jeffrey');
