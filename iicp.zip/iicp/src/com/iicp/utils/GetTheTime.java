package com.iicp.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class GetTheTime {
	public static String getTheDateTime(){
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		return simpleDateFormat.format(new Date());
	}
	
	public String getTheTime(){
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
		return simpleDateFormat.format(new Date());
	}
	
	public String getTheMonth(){
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM");
		return simpleDateFormat.format(new Date());
	}
	
	public static String getHowLong(String datetime1,String datetime2){
		String result = null;
		DateFormat df = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
		try {
			Date d1 = df.parse(datetime1);
			Date d2 = df.parse(datetime2);
			long diff = d1.getTime() - d2.getTime();
			long days = diff/(1000 * 60 * 60 * 24);
			long hours = (diff-days*(1000 * 60 * 60 * 24))/(1000* 60 * 60);
			long minutes = (diff-days*(1000 * 60 * 60 * 24)-hours*(1000* 60 * 60))/(1000* 60);
			result = ""+days+"��"+hours+"Сʱ"+minutes+"��";
		} catch (Exception e){
			e.printStackTrace();
		}
		return result;
	}
}
