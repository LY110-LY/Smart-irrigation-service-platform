package com.iicp.utils;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.iicp.entity.Irrigated;



public class ExportIrrgatedExcel{

    public void exportExcel(List<Irrigated> listIrrigated) throws Exception{
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("Irrigated"); 
        HSSFRow row = sheet.createRow((int) 0);
        HSSFCellStyle style = wb.createCellStyle();
        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        
        HSSFCell cell = row.createCell((short) 0);  
        
        cell.setCellValue("ID");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 1);  
        
        cell.setCellValue("irrname");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 2);  
        
        cell.setCellValue("irrplace");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 3);  
        
        cell.setCellValue("survey");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 4);  
        
        cell.setCellValue("distriimg");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 5);  
        
        List list = listIrrigated;
        
        int j=0;
        for (int i = 0; i < list.size(); i++)  
        {  
        	row = sheet.createRow(++j);
        	Irrigated irrigated = (Irrigated) list.get(i);
            row.createCell((short) 0).setCellValue(irrigated.getID());  
            row.createCell((short) 1).setCellValue(irrigated.getIrrname());
            row.createCell((short) 2).setCellValue(irrigated.getIrrplace());
            row.createCell((short) 3).setCellValue(irrigated.getSurvey());
            row.createCell((short) 4).setCellValue(irrigated.getDistriimg());
        }  
        try  
        {  
            FileOutputStream fout = new FileOutputStream("E:/Irrigated.csv");  
            wb.write(fout);  
            fout.close();  
        }  
        catch (Exception e)  
        {  
            e.printStackTrace();  
        }  
    }
    

}

