package com.iicp.utils;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.iicp.entity.History;


public class ExportHistoryExcel{

    public void exportExcel(List<History> listHistory) throws Exception{
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("History"); 
        HSSFRow row = sheet.createRow((int) 0);
        HSSFCellStyle style = wb.createCellStyle();
        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        
        HSSFCell cell = row.createCell((short) 0);  
        
        cell.setCellValue("uid");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 1);  
        
        cell.setCellValue("ID");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 2);  
        
        cell.setCellValue("opening");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 3);  
        
        cell.setCellValue("flow");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 4);  
        
        cell.setCellValue("upstream");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 5);  
        
        cell.setCellValue("downstream");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 6);  
        
        cell.setCellValue("locklimit");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 7); 
        
        cell.setCellValue("dam_state");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 8);  
        
        cell.setCellValue("motor_state");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 9); 
        
        cell.setCellValue("timestamp");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 10);
        
        cell.setCellValue("opcode");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 11);  
        
        List list = listHistory;
        
        int j=0;
        for (int i = 0; i < list.size(); i++)  
        {  
        	row = sheet.createRow(++j);
        	History history = (History) list.get(i);
            row.createCell((short) 0).setCellValue(history.getUid());  
            row.createCell((short) 1).setCellValue(history.getID());
            row.createCell((short) 2).setCellValue(history.getOpening());
            row.createCell((short) 3).setCellValue(history.getFlow());
            row.createCell((short) 4).setCellValue(history.getUpstream());
            row.createCell((short) 5).setCellValue(history.getDownstream());
            row.createCell((short) 6).setCellValue(history.getLocklimit());
            row.createCell((short) 7).setCellValue(history.getDam_state());
            row.createCell((short) 8).setCellValue(history.getDam_state());
            row.createCell((short) 9).setCellValue(history.getTimestamp());
            row.createCell((short) 10).setCellValue(history.getOpcode());
        }  
        try  
        {  
            FileOutputStream fout = new FileOutputStream("E:/History.csv");  
            wb.write(fout);  
            fout.close();  
        }  
        catch (Exception e)  
        {  
            e.printStackTrace();  
        }  
    }
    

}

