package com.iicp.utils;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.iicp.entity.Sluice;


public class ExportSluiceExcel{

    public void exportExcel(List<Sluice> listSluice) throws Exception{
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("Sluice"); 
        HSSFRow row = sheet.createRow((int) 0);
        HSSFCellStyle style = wb.createCellStyle();
        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        
        HSSFCell cell = row.createCell((short) 0);  
        
        cell.setCellValue("ID");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 1);  
        
        cell.setCellValue("irrid");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 2);  
        
        cell.setCellValue("sluicename");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 3);  
        
        cell.setCellValue("width");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 4);  
        
        cell.setCellValue("height");  
        cell.setCellStyle(style);  
        cell = row.createCell((short) 5);  
        
        List list = listSluice;
        
        int j=0;
        for (int i = 0; i < list.size(); i++)  
        {  
        	row = sheet.createRow(++j);
        	Sluice sluice = (Sluice) list.get(i);
            row.createCell((short) 0).setCellValue(sluice.getID());  
            row.createCell((short) 1).setCellValue(sluice.getIrrid());
            row.createCell((short) 2).setCellValue(sluice.getSluicename());
            row.createCell((short) 3).setCellValue(sluice.getWidth());
            row.createCell((short) 4).setCellValue(sluice.getHeight());
        }  
        try  
        {  
            FileOutputStream fout = new FileOutputStream("E:/Sluice.csv");  
            wb.write(fout);  
            fout.close();  
        }  
        catch (Exception e)  
        {  
            e.printStackTrace();  
        }  
    }
    

}

