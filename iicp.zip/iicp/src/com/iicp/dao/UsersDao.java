package com.iicp.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.iicp.entity.Users;

public class UsersDao extends BaseDao{
	/**
	 * ��ѯ��������
	 * @return
	 */
	public List<Users> selectAll(){
		List<Users> list = new ArrayList<Users>();
		String sql = "select * from users";
		ResultSet rs = super.exeQuery(sql,null);
		try {
			while(rs.next()){
				Users user = new Users();
				user.setID(rs.getInt("ID"));
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setFullname(rs.getString("fullname"));
				user.setDepartment(rs.getString("department"));
				user.setTel(rs.getString("tel"));
				user.setEmail(rs.getString("email"));
				list.add(user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			super.closeAll();
		}
		return list;
	}
	
	/**
	 * ͨ��ID����һ����¼
	 * @param user
	 * @param id
	 * @return
	 */
	public int updateById(Users user,int id){
		String sql = "update users set username=?,password=?,fullname=?,department=?,tel=?,email=? where ID = ?";
		Object[] values = {user.getUsername(),user.getPassword(),user.getFullname(),user.getDepartment(),user.getTel(),user.getEmail(),id};
		return super.exeUpdate(sql, values);
	}
	
	/**
	 * ͨ��IDɾ��һ����¼
	 * @param id
	 * @return
	 */
	public int deleteById(int id){
		String sql = "delete from users where ID = ?";
		Object[] values = {id};
		return super.exeUpdate(sql, values);
	}
	
	/**
	 * ����һ������
	 * @param user
	 * @return
	 */
	public int insertUsers(Users user){
		int result = 0;
		String sql = "insert into users(username,password,fullname,department,tel,email) values(?,?,?,?,?,?)";
		Object[] values = {user.getUsername(),user.getPassword(),user.getFullname(),user.getPassword(),user.getTel(),user.getEmail()};
		result = super.exeUpdate(sql, values);
		return result;
	}
	
	/**
	 * ͨ��username��ѯusername,fullname,department,tel,email
	 * @param username
	 * @return username,fullname,department,tel,email
	 */
	public Users selectUsersInfomationByUsername(String username){
		String sql = "select * from users where username = ?";
		Object[] values = {username};
		ResultSet rs = super.exeQuery(sql, values);
		Users users = new Users();
		try{
			if(rs.next()){
				users.setUsername(rs.getString("username"));
				users.setFullname(rs.getString("fullname"));
				users.setDepartment(rs.getString("department"));
				users.setTel(rs.getString("tel"));
				users.setEmail(rs.getString("email"));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return users;
	}
	
	/**
	 * ͨ���û��������û���������
	 * @param username
	 * @return
	 */
	public Users selectPasswordByUsername(String username){
		Users user = null;
		String sql = "select username,password from users where username=?";
		Object[] values = {username};
		ResultSet rs = super.exeQuery(sql, values);
		try {
			if(rs.next()){
				user = new Users();
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			super.closeAll();
		}
		return user;
	}
	
	/**
	 * ͨ��username�޸�password
	 * @param username
	 * @param password
	 */
	public void updatePasswordByUsername(String username,String password){
		String sql = "update users set password = ? where username = ?";
		Object[] values = {username,password};
		super.exeUpdate(sql, values);
	}
	
}
