package com.iicp.dao;

import com.iicp.entity.Webbuffer;

public class WebbufferDao extends BaseDao{

	/**
	 * ����һ��webbuffer��¼
	 * @param webbuffer
	 * @return
	 */
	public int insertWebbuffer(Webbuffer webbuffer){
		int result = 1;
		String sql = "insert into webbuffer(opcode,ID,value,username) values(?,?,?,?)";
		Object[] values = {webbuffer.getOpcode(),webbuffer.getID(),webbuffer.getValue(),webbuffer.getUsername()};
		result = super.exeUpdate(sql, values);
		return result;
	}
	
}
