package com.iicp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BaseDao{
	private static final String DRIVER_CLASS = "com.mysql.jdbc.Driver";
	private static final String DATABASE_URL = "jdbc:mysql://127.0.0.1:3306/mdb?useUnicode=true&characterEncoding=utf-8";
	private static final String DATABASE_USER = "root";
	private static final String DATABASE_PASSWORD = "123456";
	
	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;
	
	public BaseDao(){
		try{
			Class.forName(DRIVER_CLASS);
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
	}
	
	/**
	 * �������ݿ�
	 */
	public Connection getConnection(){
		Connection dbConnection = null;
		try{
			Class.forName(DRIVER_CLASS);
			dbConnection = DriverManager.getConnection(DATABASE_URL,
					DATABASE_USER, DATABASE_PASSWORD);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return dbConnection;
	}	
	
	/**
	 * ͨ�õ���ɾ�ķ���
	 */
	public int exeUpdate(String sql,Object[] values){
		int result = 0;
		try{
			conn=getConnection();
			pst = conn.prepareStatement(sql);
			if(values!=null){
				for(int i=0;i<values.length;i++){
					pst.setObject(i+1, values[i]);
				}
			}
			result = pst.executeUpdate();
		}catch (SQLException e) {
			e.printStackTrace();
		}finally{
			closeAll();
		}
		return result;
	}

	/**
	 * ͨ�õĲ�ѯ����
	 */
	public ResultSet exeQuery(String sql,Object[] values){
		try{
			conn=getConnection();
			pst = conn.prepareStatement(sql);
			if(values!=null){
				for(int i=0;i<values.length;i++){
					pst.setObject(i+1, values[i]);
				}
			}
			rs = pst.executeQuery();
		}catch (SQLException e) {
			e.printStackTrace();
		}finally{
			//��ѯʱ���ر����ݿ����ӣ�����֮���ڹر�
		}
		return rs;
	}
	
	/**
	 * �ر�����
	 */
	public void closeAll() {
		//�رս����
		try{
			if(rs!=null) {
				rs.close();
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		//�ر����ݿ��ѯ���
		try{
			if(pst!= null){
				pst.close();
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		//�ر����ݿ�����
		try{
			if(conn!=null && (!conn.isClosed())){
				conn.close();
			}
		}catch(SQLException sqlEx){
			sqlEx.printStackTrace();
		}
	}
}