package com.iicp.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.iicp.entity.Mito;

public class MitoDao extends BaseDao{
	
	/**
	 * ��ѯ��������
	 * @return List<Irrigated>
	 */
	public List<Mito> selectAll(){
		List<Mito> list = new ArrayList<Mito>();
		String sql = "select * from mito";
		ResultSet rs = super.exeQuery(sql,null);
		try{
			while(rs.next()){
				Mito mito = new Mito();
				mito.setID(rs.getInt("ID"));
				mito.setFullname(rs.getString("fullname"));
				mito.setArea(rs.getString("area"));
				mito.setCroptype(rs.getString("croptype"));
				mito.setPlace(rs.getString("place"));
				mito.setSluiceid(rs.getInt("sluiceid"));
				mito.setTel(rs.getString("tel"));
				list.add(mito);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}
	
	/**
	 * ����һ��MitoDao��¼
	 * @param mito
	 * @return int
	 */
	public int insertMito(Mito mito){
		int result = 0;
		String sql = "INSERT INTO mito(fullname,area,croptype,place,sluiceid,tel) values(?,?,?,?,?,?)";
		Object[] values = {mito.getFullname(),mito.getArea(),mito.getCroptype(),mito.getPlace(),mito.getSluiceid(),mito.getTel()};
		result = super.exeUpdate(sql,values);
		return result;
	}
	
	/**
	 * ͨ��IDɾ��
	 * @param ID
	 */
	public int deleteMito(int ID){
		String sql = "delete from mito where ID = ?";
		Object[] values = {ID};
		return super.exeUpdate(sql, values);
	}
	
	/**
	 * ͨ��ID������Ϣ
	 * @param mito
	 */
	public int updateMito(Mito mito,int ID){
		String sql = "update mito set fullname=?,area=?,croptype=?,place=?,sluiceid=?,tel=? where ID = ?";
		Object[] values = {mito.getFullname(),mito.getArea(),mito.getCroptype(),mito.getPlace(),mito.getSluiceid(),mito.getTel(),ID};
		return super.exeUpdate(sql, values);
	}
	
	/**
	 * ��ѯ���м�¼����
	 * @return int
	 */
	public int selectMitoNumber(){
		List<Mito> list = selectAll();
		return list.size();
	}
	
}
