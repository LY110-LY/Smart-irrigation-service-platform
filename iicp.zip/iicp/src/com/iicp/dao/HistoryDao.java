package com.iicp.dao;

import java.io.File;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.iicp.entity.History;
import com.iicp.utils.ExportHistoryExcel;
import com.iicp.utils.GetTheTime;
import com.iicp.utils.WriteInDB;

public class HistoryDao extends BaseDao{
	
	GetTheTime getTheTime = new GetTheTime();
	
	ExportHistoryExcel exportHistory = new ExportHistoryExcel();
	
	/**
	 * ����������ʷ��¼
	 * @return List<History>
	 */
	public List<History> selectAllHistory(){
		List<History> historyList = new ArrayList<History>();
		String sql = "select * from history";
		ResultSet rs = super.exeQuery(sql,null);
		try{
			while(rs.next()){
				History history = new History();
				history.setUid(rs.getInt("uid"));
				history.setID(rs.getInt("ID"));
				history.setLocklimit(rs.getInt("locklimit"));
				history.setDam_state(rs.getInt("dam_state"));
				history.setMotor_state(rs.getInt("motor_state"));
				history.setOpcode(rs.getInt("opcode"));
				history.setTimestamp(rs.getString("timestamp"));
				history.setOpening(rs.getDouble("opening"));
				history.setFlow(rs.getDouble("flow"));
				history.setUpstream(rs.getDouble("upstream"));
				history.setDownstream(rs.getDouble("downstream"));
				historyList.add(history);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return historyList;
	}
	
	/**
	 * ͨ��ID���ҵ��յĿ��Ⱥ������͵��վ���ʱ��
	 * @param ID
	 * @return opening flow timestamp
	 */
	public List<History> selectTheDayOpeningAndFlowAndTimestampByID(int ID){
		List<History> list = new ArrayList<History>();
		String sql = "select opening,flow,timestamp from history where ID = ? and timestamp like ?";
		String timestamp = getTheTime.getTheTime()+"%";
		Object[] values = {ID,timestamp};
		ResultSet rs = super.exeQuery(sql, values);
		try{
			while(rs.next()){
				History history = new History(rs.getDouble("opening"), rs.getDouble("flow"), rs.getString("timestamp"));
				list.add(history);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}
	
	/**
	 * ͨ��ID��ѯ��������ˮλ������ˮλ�͵��վ���ʱ��
	 * @param ID
	 * @return upstream downstream timestamp
	 */
	public List<History> selectTheDayUpstramAndDownstramAndTimestampByID(int ID){
		List<History> list = new ArrayList<History>();
		String sql = "select upstream,downstream,timestamp from history where ID = ? and timestamp like ?";
		String timestamp = getTheTime.getTheTime()+"%";
		Object[] values = {ID,timestamp};
		ResultSet rs = super.exeQuery(sql, values);
		try{
			while(rs.next()){
				History history = new History(rs.getString("timestamp"), rs.getDouble("upstream"), rs.getDouble("downstream"));
				list.add(history);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}
	
	/**
	 * ͨ��ID��ѯ�����������ˮλ
	 * @param id
	 * @return
	 */
	public List<History> selectRecentlyUpstreamAndDownStreamAndTimestampByID(int id){
		List<History> list = new ArrayList<History>();
//		String sql = "select ID,upstream,downstream,timestamp from history where ID = ? limit 15";
		String sql = "select * from (select uid,ID,upstream,downstream,timestamp from history where ID = ? order by uid desc limit 0,15) as tbl order by tbl.uid asc";
		Object[] values = {id};
		ResultSet rs = super.exeQuery(sql, values);
		try{
			while(rs.next()){
				History history = new History(rs.getString("timestamp"), rs.getDouble("upstream"), rs.getDouble("downstream"));
				list.add(history);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}
	
	/**
	 * �˷���ʵ�ַ�ҳ
	 * @param pagesize
	 * @param pageindex
	 * @return
	 */
	public List<History> selAllHistoryByPage(int pagesize,int pageindex){
		List<History> historylist = new ArrayList<History>();
		String sql = "select * from history where uid <= (select count(*) from history)-"+pagesize+"*"+(pageindex-1)+" order by uid desc limit 0,"+pagesize;
		ResultSet rs = super.exeQuery(sql, null);
		try {
			while(rs.next()){
				History history = new History();
				history.setUid(rs.getInt("uid"));
				history.setID(rs.getInt("ID"));
				history.setLocklimit(rs.getInt("locklimit"));
				history.setDam_state(rs.getInt("dam_state"));
				history.setMotor_state(rs.getInt("motor_state"));
				history.setOpcode(rs.getInt("opcode"));
				history.setTimestamp(rs.getString("timestamp"));
				history.setOpening(rs.getDouble("opening"));
				history.setFlow(rs.getDouble("flow"));
				history.setUpstream(rs.getDouble("upstream"));
				history.setDownstream(rs.getDouble("downstream"));
				historylist.add(history);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return historylist;
	}

	/**
	 * �˷������ҳ������
	 * @return
	 */
	public int selHistoryCount(){
		int count = 0;
		String sql = "select count(*) num from history";
		ResultSet rs = super.exeQuery(sql, null);
		try {
			if(rs.next()){
				count = rs.getInt("num");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return count;
	}
	
	/**
	 * ����History��Excel�ļ�(csv)
	 */
	public void exportHistoryExcel(){
		List<History> list = selectAllHistory();
		try {
			exportHistory.exportExcel(list);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
