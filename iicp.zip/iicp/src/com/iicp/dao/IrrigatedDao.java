package com.iicp.dao;

import java.io.File;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.iicp.entity.Irrigated;
import com.iicp.utils.ExportIrrgatedExcel;
import com.iicp.utils.WriteInDB;

public class IrrigatedDao extends BaseDao{
	
	ExportIrrgatedExcel exportIrrgated = new ExportIrrgatedExcel();
	
	WriteInDB writeInIrrigated = new WriteInDB();
	
	/**
	 * ��ѯ��������
	 * @return List<Irrigated>
	 */
	public List<Irrigated> selectAll(){
		List<Irrigated> list = new ArrayList<Irrigated>();
		String sql = "select * from irrigated";
		ResultSet rs = super.exeQuery(sql,null);
		try{
			while(rs.next()){
				Irrigated irrigated = new Irrigated();
				irrigated.setID(rs.getInt("ID"));
				irrigated.setIrrname(rs.getString("irrname"));
				irrigated.setIrrplace(rs.getString("irrplace"));
				irrigated.setSurvey(rs.getString("survey"));
				irrigated.setDistriimg(rs.getString("distriimg"));
				list.add(irrigated);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}
	
	/**
	 * ��ѯ����բվ����
	 * @return List<String>
	 */
	public List<String> selectAllIrrname(){
		List<String> list = new ArrayList<String>();
		String sql = "SELECT irrname FROM irrigated";
		ResultSet rs = super.exeQuery(sql,null);
		try{
			while(rs.next()){
				list.add(rs.getString("irrname"));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}
	
	/**
	 * ����һ��irrigated��¼
	 * @param irrigated
	 * @return int
	 */
	public int insertIrrigated(Irrigated irrigated){
		int result = 0;
		String sql = "INSERT INTO irrigated(irrname,irrplace,survey,distriimg) values(?,?,?,?)";
		Object[] values = {irrigated.getIrrname(),irrigated.getIrrplace(),irrigated.getSurvey(),irrigated.getDistriimg()};
		result = super.exeUpdate(sql,values);
		return result;
	}
	
	/**
	 * ͨ��IDɾ��
	 * @param ID
	 */
	public int deleteIrrigated(int ID){
		String sql = "delete from irrigated where ID = ?";
		Object[] values = {ID};
		return super.exeUpdate(sql, values);
	}
	
	/**
	 * ͨ��ID������Ϣ
	 * @param irrigated
	 */
	public int updateIrrigated(Irrigated irrigated,int ID){
		String sql = "update irrigated set irrname=?,irrplace=?,survey=?,distriimg=? where ID = ?";
		Object[] values = {irrigated.getIrrname(),irrigated.getIrrplace(),irrigated.getSurvey(),irrigated.getDistriimg(),ID};
		return super.exeUpdate(sql, values);
	}
	
	/**
	 * ����Irrgated��
	 */
	public void exportIrrgated(){
		List<Irrigated> list = selectAll();
		try {
			exportIrrgated.exportExcel(list);
		} catch (Exception e) {
			System.out.println("����Irrgated��ʧ�ܣ�");
			e.printStackTrace();
		}
	}
	
	/**
	 * ��csv�������ݿ�
	 * @param fileAddr
	 */
	public void writeInIrrigatedDB(String fileAddr){
		//E:/Irrigated.csv
		File file = new File(fileAddr);  
        ArrayList<ArrayList<Object>> result = WriteInDB.readExcel(file);  
        List<String> listString = new ArrayList<String>();
        double num = 0;
        for(int i=1;i<result.size();i++){
        	Irrigated irrigated = new Irrigated();
        	for(int j=0;j<result.get(i).size();j++){
        		String str = String.valueOf(result.get(i).get(j));
        		switch (j) {
					case 0:num=Double.parseDouble(str);irrigated.setID((int)num);break;
					case 1:irrigated.setIrrname(str);break;
					case 2:irrigated.setIrrplace(str);break;
					case 3:irrigated.setSurvey(str);break;
					case 4:irrigated.setDistriimg(str);break;
				}
        	}
        	insertIrrigated(irrigated);
        }
	}
	
	public static void main(String[] args) {
		IrrigatedDao i = new IrrigatedDao();
		i.writeInIrrigatedDB("E:/Irrigated.csv");
	}
	
}
