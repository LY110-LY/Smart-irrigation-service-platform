package com.iicp.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.iicp.entity.Realtimestatus;

public class RealtimestatusDao extends BaseDao{
	
	/**
	 * ��ѯ��������
	 * @return
	 */
	public List<Realtimestatus> selectAll(){
		List<Realtimestatus> list = new ArrayList<Realtimestatus>();
		String sql = "select * from realtimestatus";
		ResultSet rs = super.exeQuery(sql, null);
		try{
			while(rs.next()){
				Realtimestatus r = new Realtimestatus();
				r.setID(rs.getInt("ID"));
				r.setLocklimit(rs.getInt("locklimit"));
				r.setDam_state(rs.getInt("dam_state"));
				r.setMotor_state(rs.getInt("motor_state"));
				r.setOpcode(rs.getInt("opcode"));
				r.setOpening(rs.getDouble("opening"));
				r.setFlow(rs.getDouble("flow"));
				r.setUpstream(rs.getDouble("upstream"));
				r.setDownstream(rs.getDouble("downstream"));
				list.add(r);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}
	
	/**
	 * ��ѯբվ����
	 * @return int
	 */
	public int selectSluiceNumber(){
		List<Realtimestatus> list = selectAll();
		return list.size();
	}
	
	/**
	 * ��ѯ���е��״̬
	 * @return List<Integer>
	 */
	public List<Integer> selectAllMotorState(){
		List<Integer> list = new ArrayList<Integer>();
		String sql = "select motor_state from realtimestatus";
		ResultSet rs = super.exeQuery(sql, null);
		try{
			while(rs.next()){
				list.add(rs.getInt("motor_state"));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}
	
	/**
	 * ����ID��ѯ��Ϣ
	 * @param ID
	 * @return
	 */
	public List<Realtimestatus> selectAllByID(int ID){
		List<Realtimestatus> list = new ArrayList<Realtimestatus>();
		String sql = "select * from realtimestatus where ID = ?";
		Object[] values = {ID};
		ResultSet rs = super.exeQuery(sql, values);
		try {
			while(rs.next()){
				Realtimestatus r = new Realtimestatus();
				r.setID(rs.getInt("ID"));
				r.setLocklimit(rs.getInt("locklimit"));
				r.setDam_state(rs.getInt("dam_state"));
				r.setMotor_state(rs.getInt("motor_state"));
				r.setOpcode(rs.getInt("opcode"));
				r.setOpening(rs.getDouble("opening"));
				r.setFlow(rs.getDouble("flow"));
				r.setUpstream(rs.getDouble("upstream"));
				r.setDownstream(rs.getDouble("downstream"));
				list.add(r);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}
	
}
