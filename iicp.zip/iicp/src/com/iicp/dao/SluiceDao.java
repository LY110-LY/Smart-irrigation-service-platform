package com.iicp.dao;

import java.io.File;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.iicp.entity.Sluice;
import com.iicp.utils.ExportSluiceExcel;
import com.iicp.utils.WriteInDB;

public class SluiceDao extends BaseDao{
	
	ExportSluiceExcel exportSluiceExcel = new ExportSluiceExcel();
	
	WriteInDB writeInSluice = new WriteInDB();
	
	/**
	 * ��ѯ��������
	 * @return
	 */
	public List<Sluice> selectAll(){
		List<Sluice> list = new ArrayList<Sluice>();
		String sql = "select * from sluice";
		ResultSet rs = super.exeQuery(sql, null);
		try{
			while(rs.next()){
				Sluice sluice = new Sluice();
				sluice.setID(rs.getInt("ID"));
				sluice.setIrrid(rs.getInt("irrid"));
				sluice.setSluicename(rs.getString("sluicename"));
				sluice.setWidth(rs.getDouble("width"));
				sluice.setHeight(rs.getDouble("height"));
				sluice.setRemarks(rs.getString("remarks"));
				list.add(sluice);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}
	
	/**
	 * ����һ������
	 * @param sluice
	 * @return
	 */
	public int insertSluice(Sluice sluice){
		int result = 0;
		String sql = "insert into sluice(ID,irrid,sluicename,width,height,remarks) values(?,?,?,?,?,?)";
		Object[] values = {sluice.getID(),sluice.getIrrid(),sluice.getSluicename(),sluice.getWidth(),sluice.getHeight(),sluice.getRemarks()};
		result = super.exeUpdate(sql, values);
		return result;
	}
	
	/**
	 * ����IDɾ��
	 * @param ID
	 */
	public int deleteSluiceByID(int ID){
		String sql = "delete from sluice where ID = ?";
		Object[] values = {ID};
		return super.exeUpdate(sql, values);
	}
	
	/**
	 * ͨ��ID�޸�ֵ
	 * @param sluice
	 */
	public int updateSluice(Sluice sluice,int ID){
		String sql = "update Sluice set irrid=?,sluicename=?,width=?,height=?,remarks=? where ID = ?";
		Object[] values = {sluice.getIrrid(),sluice.getSluicename(),sluice.getWidth(),sluice.getHeight(),sluice.getRemarks(),ID};
		return super.exeUpdate(sql, values);
	}
	
	/**
	 * ������м�¼����
	 * @return
	 */
	public int getSluiceNumber(){
		return selectAll().size();
	}
	
	/**
	 * ��ѯ����բվ������
	 * @return List<Sluice>
	 */
	public List<Sluice> selectAllIrridAndSluicename(){
		List<Sluice> list = new ArrayList<Sluice>();
		String sql = "select irrid,sluicename from sluice";
		ResultSet rs = super.exeQuery(sql, null);
		try{
			while(rs.next()){
				Sluice sluice = new Sluice();
				sluice.setIrrid(rs.getInt("irrid"));
				sluice.setSluicename(rs.getString("sluicename"));
				list.add(sluice);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}
	
	/**
	 * ����Sluice����
	 */
	public void exportSluice(){
		List<Sluice> list = selectAll();
		try {
			exportSluiceExcel.exportExcel(list);
		} catch (Exception e) {
			System.out.println("����Sluice��ʧ�ܣ�");
			e.printStackTrace();
		}
	}
	
	/**
	 * ��csv���뵽���ݿ�
	 * @param fileAddr
	 */
	public void writeInSluiceDB(String fileAddr){
		File file = new File(fileAddr);  
        ArrayList<ArrayList<Object>> result = WriteInDB.readExcel(file);  
        double num = 0;
        for(int i=1;i<result.size();i++){
        	Sluice sluice = new Sluice();
        	for(int j=0;j<result.get(i).size();j++){
        		String str = String.valueOf(result.get(i).get(j));
        		switch (j) {
					case 0:num=Double.parseDouble(str);sluice.setID((int)num);break;
					case 1:num=Double.parseDouble(str);sluice.setIrrid((int)num);break;
					case 2:sluice.setSluicename(str);break;
					case 3:num=Double.parseDouble(str);sluice.setWidth(num);break;
					case 4:num=Double.parseDouble(str);sluice.setHeight(num);break;
				}
        	}
        	insertSluice(sluice);
        }
	}
	
}
