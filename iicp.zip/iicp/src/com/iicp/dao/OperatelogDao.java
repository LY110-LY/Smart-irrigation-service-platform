package com.iicp.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.iicp.entity.Operatelog;


public class OperatelogDao extends BaseDao{
	
	/**
	 * ��ѯ��������
	 * @return
	 */
	public List<Operatelog> selectAll(){
		List<Operatelog> list = new ArrayList<Operatelog>();
		String sql = "select * from operatelog";
		ResultSet rs = super.exeQuery(sql,null);
		try{
			while(rs.next()){
				Operatelog operateLog = new Operatelog();
				operateLog.setOpcode(rs.getInt("opcode"));
				operateLog.setUsername(rs.getString("username"));
				operateLog.setOperatetime(rs.getString("operatetime"));
				operateLog.setIpaddr(rs.getString("ipaddr"));
				list.add(operateLog);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}
	
}
