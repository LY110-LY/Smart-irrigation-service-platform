package com.iicp.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.iicp.entity.Transfer;
import com.iicp.utils.GetTheTime;


public class TransferDao extends BaseDao{

	GetTheTime getTheTime = new GetTheTime();
	
	/**
	 * ��ѯ��������
	 * @return
	 */
	public List<Transfer> selectAll(){
		List<Transfer> list = new ArrayList<Transfer>();
		String sql = "select * from transfer";
		ResultSet rs = super.exeQuery(sql,null);
		try {
			while(rs.next()){
				Transfer transfer = new Transfer();
				transfer.setID(rs.getInt("ID"));
				transfer.setSluiceid(rs.getInt("sluiceid"));
				transfer.setMitoname(rs.getString("mitoname"));
				transfer.setStarttime(rs.getString("starttime"));
				transfer.setEndtime(rs.getString("endtime"));
				transfer.setHowlong(rs.getString("howlong"));
				transfer.setCompletion(rs.getString("completion"));
				transfer.setDatatime(rs.getString("datatime"));
				transfer.setSysuser(rs.getString("sysuser"));
				transfer.setOrderwater(rs.getDouble("orderwater"));
				transfer.setActualwater(rs.getDouble("actualwater"));
				list.add(transfer);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}
	
	/**
	 * ����һ������
	 * @param transfer
	 * @return
	 */
	public int insertTransfer(Transfer transfer){
		int result = 0;
		String sql = "insert into Transfer(sluiceid,mitoname,starttime,endtime,howlong,completion,datatime,sysuser,orderwater,actualwater) values(?,?,?,?,?,?,?,?,?,?)";
		Object[] values = {transfer.getSluiceid(),transfer.getMitoname(),transfer.getStarttime(),transfer.getEndtime(),transfer.getHowlong(),transfer.getCompletion(),transfer.getDatatime(),transfer.getSysuser(),transfer.getOrderwater(),transfer.getActualwater()};
		result = super.exeUpdate(sql, values);
		return result;
	}
	
	/**
	 * ͨ��IDɾ������
	 * @param ID
	 */
	public int deleteByID(int ID){
		String sql = "delete from transfer where ID = ?";
		Object[] values = {ID};
		return super.exeUpdate(sql, values);
	}
	
	/**
	 * ͨ��ID���¼�¼
	 * @param transfer
	 */
	public int updateByID(Transfer transfer,int ID){
		String sql = "update transfer set sluiceid=?,mitoname=?,starttime=?,endtime=?,howlong=?,completion=?,datatime=?,sysuser=?,orderwater=?,actualwater=? where ID = ?";
		Object[] values = {transfer.getSluiceid(),transfer.getMitoname(),transfer.getStarttime(),transfer.getEndtime(),transfer.getHowlong(),transfer.getCompletion(),transfer.getDatatime(),transfer.getSysuser(),transfer.getOrderwater(),transfer.getActualwater(),ID};
		return super.exeUpdate(sql, values);
	}
	
	/**
	 * ��ѯ����ļ�¼����
	 * @return
	 */
	public int selectTransferByDay(){
		String sql = "select * from transfer where datatime like ?";
		String datatime = getTheTime.getTheTime()+"%";
		Object[] values = {datatime};
		ResultSet rs = super.exeQuery(sql, values);
		int i = 0;
		try {
			while(rs.next()){
				++i;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return i;
	}
	
	/**
	 * ��ѯ���¼�¼
	 * @return
	 */
	public List<Transfer> selectAllInTheMonth(){
		List<Transfer> list = new ArrayList<Transfer>();
		String sql = "select * from transfer where datatime like ?";
		String datatime = getTheTime.getTheMonth()+"%";
		Object[] values = {datatime};
		ResultSet rs = super.exeQuery(sql,values);
		try {
			while(rs.next()){
				Transfer transfer = new Transfer();
				transfer.setID(rs.getInt("ID"));
				transfer.setSluiceid(rs.getInt("sluiceid"));
				transfer.setMitoname(rs.getString("mitoname"));
				transfer.setStarttime(rs.getString("starttime"));
				transfer.setEndtime(rs.getString("endtime"));
				transfer.setHowlong(rs.getString("howlong"));
				transfer.setCompletion(rs.getString("completion"));
				transfer.setDatatime(rs.getString("datatime"));
				transfer.setSysuser(rs.getString("sysuser"));
				transfer.setOrderwater(rs.getDouble("orderwater"));
				transfer.setActualwater(rs.getDouble("actualwater"));
				list.add(transfer);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}
	
}
