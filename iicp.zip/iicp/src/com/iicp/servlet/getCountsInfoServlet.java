package com.iicp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.iicp.entity.Transfer;
import com.iicp.service.MitoService;
import com.iicp.service.RealtimestatusService;
import com.iicp.service.SluiceService;
import com.iicp.service.TransferService;

public class getCountsInfoServlet extends HttpServlet {
	private SluiceService sluiceService = new SluiceService();
	private RealtimestatusService realtimestatusService = new RealtimestatusService();
	private TransferService transferService = new TransferService();
	private MitoService mitoService = new MitoService();
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.print(getJsonInfo());
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	public String getJsonInfo(){
		List<Transfer> list_trans = transferService.getAll();
		int count_carry = 0;
		int count_undone = 0;
		for(int i=0;i<list_trans.size();i++){
			if("100.00".equals(list_trans.get(i).getCompletion())){
				count_carry++;
			}else{
				count_undone++;
			}
		}
		int count_sluice = sluiceService.getSluiceNumber();
		int count_run = realtimestatusService.getSluiceNumber();
		int count_today_trans = transferService.getInDay();
		int count_mitouser = mitoService.getSize();
		
		List<String> list_json = new ArrayList<String>();
		list_json.add(Integer.toString(count_sluice));
		list_json.add(Integer.toString(count_run));
		list_json.add(Integer.toString(count_carry));
		list_json.add(Integer.toString(count_mitouser));
		list_json.add(Integer.toString(count_today_trans));
		list_json.add(Integer.toString(count_undone));
		
		Gson gson = new Gson();
		String json = gson.toJson(list_json);
		return json;
	}
}
