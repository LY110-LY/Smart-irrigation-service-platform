package com.iicp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.iicp.entity.Realtimestatus;
import com.iicp.entity.Sluice;
import com.iicp.service.RealtimestatusService;
import com.iicp.service.SluiceService;

public class getRealStatusInfoServlet extends HttpServlet {
	private RealtimestatusService realtimestatusService = new RealtimestatusService();
	private SluiceService sluiceService = new SluiceService();
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String action = request.getParameter("op");
		if("status".equals(action)){
			out.print(getStatusJsonInfo());
		}
		if("sluice".equals(action)){
			out.print(getSluiceJsonInfo());
		}
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	public String getStatusJsonInfo(){
		List<Realtimestatus> list_realstatus = realtimestatusService.getAll();
		Gson gson = new Gson();
		String json = gson.toJson(list_realstatus);
		return json;
	}
	
	public String getSluiceJsonInfo(){
		List<Sluice> list_sluice = sluiceService.getAll();
		Gson gson = new Gson();
		String json = gson.toJson(list_sluice);
		return json;
	}

}
