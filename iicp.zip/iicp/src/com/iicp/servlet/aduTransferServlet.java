package com.iicp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iicp.entity.Sluice;
import com.iicp.entity.Transfer;
import com.iicp.service.SluiceService;
import com.iicp.service.TransferService;
import com.iicp.utils.GetTheTime;

public class aduTransferServlet extends HttpServlet {
	private TransferService transferService = new TransferService();
	private SluiceService sluiceService = new SluiceService();
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String action = request.getParameter("op");
		
		if("add".equals(action)){
			String mitoname = request.getParameter("mitoname");
			String starttime = request.getParameter("starttime");
			String endtime = request.getParameter("endtime");
			String orderwater = request.getParameter("orderwater");
			String actualwater = request.getParameter("actualwater");
			String sysuser = request.getParameter("sysuser");
			String sluicename = request.getParameter("sluicename");
			
			int sluiceid = getSluiceId(sluicename);
			String datetime = GetTheTime.getTheDateTime();
			String howlong = GetTheTime.getHowLong(endtime,starttime);
			
			if(!"".equals(orderwater) && !"".equals(actualwater)){
				DecimalFormat df = new DecimalFormat("#.00");
				double completion = 100.00*Double.parseDouble(actualwater)/Double.parseDouble(orderwater);
				String complet = df.format(completion);
				Transfer transfer = new Transfer(sluiceid, mitoname, starttime,
						endtime, howlong, complet, datetime, sysuser, Double.parseDouble(orderwater), Double.parseDouble(actualwater));
				int result = transferService.add(transfer);
				if(result == 1){
					out.print("Success!");
				}
			}
		}
		if("update".equals(action)){
			String mitoname = request.getParameter("mitoname");
			String starttime = request.getParameter("starttime");
			String endtime = request.getParameter("endtime");
			String orderwater = request.getParameter("orderwater");
			String actualwater = request.getParameter("actualwater");
			String sysuser = request.getParameter("sysuser");
			String sluicename = request.getParameter("sluicename");
			String transferid = request.getParameter("transferid");
			
			int sluiceid = getSluiceId(sluicename);
			String datetime = GetTheTime.getTheDateTime();
			String howlong = GetTheTime.getHowLong(endtime,starttime);
			
			if(!"".equals(orderwater) && !"".equals(actualwater)){
				DecimalFormat df = new DecimalFormat("#.00");
				double completion = 100.00*Double.parseDouble(actualwater)/Double.parseDouble(orderwater);
				String complet = df.format(completion);
				Transfer transfer = new Transfer(sluiceid, mitoname, starttime,
						endtime, howlong, complet, datetime, sysuser, Double.parseDouble(orderwater), Double.parseDouble(actualwater));
				int result = transferService.update(transfer,Integer.parseInt(transferid));
				if(result == 1){
					out.print("Success!");
				}
			}
		}
		if("delete".equals(action)){
			String tid = request.getParameter("tid");
			int result = transferService.remove(Integer.parseInt(tid));
			if(result == 1){
				out.print("Success!");
			}
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	public int getSluiceId(String sluicename){
		int sid = 0;
		List<Sluice> list = sluiceService.getAll();
		for(int i=0;i<list.size();i++){
			if(sluicename.equals(list.get(i).getSluicename())){
				sid = list.get(i).getID();
			}
		}
		return sid;
	}
}
