package com.iicp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iicp.entity.Irrigated;
import com.iicp.service.IrrigatedService;

public class aduIrrigatedServlet extends HttpServlet {
	private IrrigatedService irrigatedService = new IrrigatedService();
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String action = request.getParameter("op");
		if("add".equals(action)){
			String irrname = request.getParameter("irrname");
			String irrplace = request.getParameter("irrplace");
			String survey = request.getParameter("survey");
			String distriimg = request.getParameter("distriimg");
			
			if(!"".equals(irrname) && !"".equals(irrplace)){
				Irrigated irrigated = new Irrigated(irrname, irrplace, survey, distriimg);
				int result = irrigatedService.add(irrigated);
				if(result == 1){
					out.print("Success!");
				}
			}
		}
		
		if("update".equals(action)){
			String irrname = request.getParameter("irrname");
			String irrplace = request.getParameter("irrplace");
			String survey = request.getParameter("survey");
			String distriimg = request.getParameter("distriimg");
			int id = 0;
			List<Irrigated> list = irrigatedService.getAll();
			for(int i=0;i<list.size();i++){
				if(irrname.equals(list.get(i).getIrrname())){
					id = list.get(i).getID();
				}
			}
			
			if(!"".equals(irrname) && !"".equals(irrplace)){
				Irrigated irrigated = new Irrigated(irrname, irrplace, survey, distriimg);
				int result = irrigatedService.update(irrigated, id);
				if(result == 1){
					out.print("Success!");
				}
			}
		}
		
		if("delete".equals(action)){
			String irrname = request.getParameter("irrname");
			int id = 0;
			List<Irrigated> list = irrigatedService.getAll();
			for(int i=0;i<list.size();i++){
				if(irrname.equals(list.get(i).getIrrname())){
					id = list.get(i).getID();
				}
			}
			if(!"".equals(irrname) && id != 0){
				int result = irrigatedService.delete(id);
				if(result == 1){
					out.print("Success!");
				}
			}
		}
		
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
