package com.iicp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iicp.entity.Irrigated;
import com.iicp.entity.Sluice;
import com.iicp.service.IrrigatedService;
import com.iicp.service.SluiceService;

public class aduSluiceServlet extends HttpServlet {
	private SluiceService sluiceService = new SluiceService();
	private IrrigatedService irrigatedService = new IrrigatedService();
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String action = request.getParameter("op");
		
		if("add".equals(action)){
			String irrname = request.getParameter("irrname");
			String sluicename = request.getParameter("sluicename");
			String width = request.getParameter("width");
			String height = request.getParameter("height");
			String remarks = request.getParameter("remarks");
			int irrId = getIrrId(irrname);
			if(!"".equals(irrname) && !"".equals(sluicename) && irrId != 0){
				Sluice sluice = new Sluice(irrId,sluicename,Double.parseDouble(width),Double.parseDouble(height),remarks);
				int result = sluiceService.add(sluice);
				if(result == 1){
					out.print("Success!");
				}
			}
		}
		
		if("update".equals(action)){
			String irrname = request.getParameter("irrname");
			String sluicename = request.getParameter("sluicename");
			String width = request.getParameter("width");
			String height = request.getParameter("height");
			String remarks = request.getParameter("remarks");
			int irrId = getIrrId(irrname);
			
			List<Sluice> list_sluice = sluiceService.getAll();
			int sluiceId = 0;
			for(int i=0;i<list_sluice.size();i++){
				if(sluicename.equals(list_sluice.get(i).getSluicename())){
					sluiceId = list_sluice.get(i).getID();
				}
			}
			
			if(!"".equals(irrname) && !"".equals(sluicename) && irrId != 0){
				Sluice sluice = new Sluice(irrId,sluicename,Double.parseDouble(width),Double.parseDouble(height),remarks);
				int result = sluiceService.update(sluice, sluiceId);
				if(result == 1){
					out.print("Success!");
				}
			}
		}
		
		if("delete".equals(action)){
			String sluicename = request.getParameter("sluicename");
			List<Sluice> list_sluice = sluiceService.getAll();
			int sluiceId = 0;
			for(int i=0;i<list_sluice.size();i++){
				if(sluicename.equals(list_sluice.get(i).getSluicename())){
					sluiceId = list_sluice.get(i).getID();
				}
			}
			if(sluiceId != 0){
				int result = sluiceService.remove(sluiceId);
				if(result == 1){
					out.print("Success!");
				}
			}
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	/**
	 * ��ȡ��բվ���ڹ�����ID��
	 * @param irrname
	 * @return
	 */
	public int getIrrId(String irrname){
		int irrId = 0;
		List<Irrigated> irrlist = irrigatedService.getAll();
		for(int i=0;i<irrlist.size();i++){
			if(irrname.equals(irrlist.get(i).getIrrname())){
				irrId = irrlist.get(i).getID();
			}
		}
		return irrId;
	}

}
