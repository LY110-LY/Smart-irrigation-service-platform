package com.iicp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iicp.entity.Sluice;
import com.iicp.entity.Webbuffer;
import com.iicp.service.SluiceService;
import com.iicp.service.WebbufferService;

public class WebbufferServlet extends HttpServlet {
	private WebbufferService webbufferService = new WebbufferService();
	private SluiceService sluiceService = new SluiceService();
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String action = request.getParameter("op");
		
		
		int set_id = 0;
		int set_op = 0;
		double set_value = 0;
		
		if("setof".equals(action)){
			List<Sluice> sluicelist = sluiceService.getAll();
			
			String open = request.getParameter("open");
			String flow = request.getParameter("flow");
			String sname = request.getParameter("sname");
			String sysuser = request.getParameter("sysuser");
			
			for(int i=0;i<sluicelist.size();i++){
				if(sname.equals(sluicelist.get(i).getSluicename())){
					set_id = sluicelist.get(i).getID();
				}
			}
			if("-1".equals(open)){	
				double flow_d = Double.valueOf(flow);
				set_op = 2001;
				set_value = flow_d;
			}
			if("-1".equals(flow)){
				double open_d = Double.valueOf(open);
				set_op = 2000;
				set_value = open_d;
			}
			
			Webbuffer webbuffer = new Webbuffer(set_op,set_id,set_value,sysuser);
			int result = webbufferService.add(webbuffer);
			if(result == 1){
				out.print("Success!");
			}
		}
		
		
		if("setocs".equals(action)){
			List<Sluice> sluicelist = sluiceService.getAll();
			
			String sname = request.getParameter("sname");
			String lock_op = request.getParameter("lock_op");
			String sysuser = request.getParameter("sysuser");
			
			for(int i=0;i<sluicelist.size();i++){
				if(sname.equals(sluicelist.get(i).getSluicename())){
					set_id = sluicelist.get(i).getID();
				}
			}
			if("lock_open".equals(lock_op)){
				set_op = 2002;
			}
			if("lock_close".equals(lock_op)){
				set_op = 2003;
			}
			if("lock_stop".equals(lock_op)){
				set_op = 2004;
			}
			Webbuffer webbuffer = new Webbuffer(set_op,set_id,0,sysuser);
			int result = webbufferService.add(webbuffer);
			if(result == 1){
				out.print("Success!");
			}
		}
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
