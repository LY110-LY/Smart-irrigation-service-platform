package com.iicp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iicp.entity.Mito;
import com.iicp.entity.Sluice;
import com.iicp.service.MitoService;
import com.iicp.service.SluiceService;

public class aduMitoServlet extends HttpServlet {
	private MitoService mitoService = new MitoService();
	private SluiceService sluiceService = new SluiceService();
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String action = request.getParameter("op");
		
		if("add".equals(action)){
			String fullname = request.getParameter("fullname");
			String area = request.getParameter("area");
			String croptype = request.getParameter("croptype");
			String place = request.getParameter("place");
			String tel = request.getParameter("tel");
			String sluicename = request.getParameter("sluicename");

			int sluiceid = getSluiceId(sluicename);
			if(!"".equals(fullname) && !"".equals(tel) && sluiceid != 0){
				Mito mito = new Mito(fullname,area,croptype,place,sluiceid,tel);
				int result = mitoService.add(mito);
				if(result == 1){
					out.print("Success!");
				}
			}
		}
		
		if("update".equals(action)){
			String fullname = request.getParameter("fullname");
			String area = request.getParameter("area");
			String croptype = request.getParameter("croptype");
			String place = request.getParameter("place");
			String tel = request.getParameter("tel");
			String sluicename = request.getParameter("sluicename");
			
			int mid = getMitoId(fullname);
			
			int sluiceid = getSluiceId(sluicename);
			if(!"".equals(fullname) && !"".equals(tel) && sluiceid != 0 && mid != 0){
				Mito mito = new Mito(fullname,area,croptype,place,sluiceid,tel);
				int result = mitoService.update(mito,mid);
				if(result == 1){
					out.print("Success!");
				}
			}
		}
		
		if("delete".equals(action)){
			String mid = request.getParameter("mid"); 
			int result = mitoService.delete(Integer.parseInt(mid));
			if(result == 1){
				out.print("Success!");
			}
		}
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	public int getSluiceId(String sluicename){
		int sid = 0;
		List<Sluice> list = sluiceService.getAll();
		for(int i=0;i<list.size();i++){
			if(sluicename.equals(list.get(i).getSluicename())){
				sid = list.get(i).getID();
			}
		}
		return sid;
	}
	
	public int getMitoId(String fullname){
		int mid = 0;
		List<Mito> list = mitoService.getAll();
		for(int i=0;i<list.size();i++){
			if(fullname.equals(list.get(i).getFullname())){
				mid = list.get(i).getID();
			}
		}
		return mid;
	}

}
