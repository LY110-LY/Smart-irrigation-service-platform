package com.iicp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.iicp.entity.History;
import com.iicp.service.HistoryService;
import com.iicp.service.RealtimestatusService;

public class getStremInDayServlet extends HttpServlet {
	private HistoryService historyService = new HistoryService();
	private RealtimestatusService realtimestatusService = new RealtimestatusService();
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		Gson gson = new Gson();
		String none_json = gson.toJson("�����ڸ�բվ��");
		if(request.getParameter("sid")!=null){
			int sid = Integer.parseInt(request.getParameter("sid"));
			int counts = realtimestatusService.getSluiceNumber();
			
			if(sid > counts){
				out.print(none_json);
			}else{
				out.print(getJsonInfo(sid));
			}
		}else{
			out.print(none_json);
		}
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	public String getJsonInfo(int id){
		List<History> hislist = historyService.getUpstramAndDownstramByID(id);
		
		if(hislist.size() == 0){
			hislist = historyService.selectRecentlyUpstreamAndDownStreamAndTimestampByID(id);
		}
		Gson gson = new Gson();
		String json = gson.toJson(hislist);
		return json;
	}

}
