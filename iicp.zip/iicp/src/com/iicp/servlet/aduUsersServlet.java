package com.iicp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.iicp.entity.Users;
import com.iicp.service.UsersService;

public class aduUsersServlet extends HttpServlet {
	private UsersService usersService = new UsersService();
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String action = request.getParameter("op");
		
		if("search".equals(action)){
			out.print(getJsonInfo());
		}
		if("add".equals(action)){
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String fullname = request.getParameter("fullname");
			String department = request.getParameter("department");
			String tel = request.getParameter("tel");
			String email = request.getParameter("email");
			
			if(!"".equals(username) && !"".equals(password)){
				Users user = new Users(username,password,fullname,department,tel,email);
				int result = usersService.add(user);
				if(result == 1){
					out.print("Success!");
				}
			}
		}
		if("update".equals(action)){
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String fullname = request.getParameter("fullname");
			String department = request.getParameter("department");
			String tel = request.getParameter("tel");
			String email = request.getParameter("email");
			
			String uid = request.getParameter("uid");
			if(!"".equals(username) && !"".equals(password)){
				Users user = new Users(username,password,fullname,department,tel,email);
				int result = usersService.update(user, Integer.parseInt(uid));
				if(result == 1){
					out.print("Success!");
				}
			}
		}
		if("delete".equals(action)){
			String uid = request.getParameter("uid"); 
			int result = usersService.delete(Integer.parseInt(uid));
			if(result == 1){
				out.print("Success!");
			}
		}
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	/**
	 * ��ȡ�������ݲ�ת��ΪJson
	 * @return
	 */
	public String getJsonInfo(){
		List<Users> userlist = usersService.getAll();
		Gson gson = new Gson();
		String json = gson.toJson(userlist);
		return json;
	}
}
