package com.iicp.entity;

public class Webbuffer {
	
	private int opcode,ID;
	private double value;
	private String username;
	
	public Webbuffer() {
		super();
	}

	public Webbuffer(int opcode, int iD, double value, String username) {
		super();
		this.opcode = opcode;
		ID = iD;
		this.value = value;
		this.username = username;
	}
	
	public int getOpcode() {
		return opcode;
	}
	public void setOpcode(int opcode) {
		this.opcode = opcode;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public double getValue() {
		return value;
	}
	public void setValue(double value) {
		this.value = value;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
}
