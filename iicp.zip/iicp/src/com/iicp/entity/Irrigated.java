package com.iicp.entity;

public class Irrigated {
	
	private int ID;
	private String irrname,irrplace,survey,distriimg;
	
	public Irrigated(){};
	
	public Irrigated(String irrname, String irrplace, String survey,
			String distriimg) {
		super();
		this.irrname = irrname;
		this.irrplace = irrplace;
		this.survey = survey;
		this.distriimg = distriimg;
	}
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getIrrname() {
		return irrname;
	}
	public void setIrrname(String irrname) {
		this.irrname = irrname;
	}
	public String getIrrplace() {
		return irrplace;
	}
	public void setIrrplace(String irrplace) {
		this.irrplace = irrplace;
	}
	public String getSurvey() {
		return survey;
	}
	public void setSurvey(String survey) {
		this.survey = survey;
	}
	public String getDistriimg() {
		return distriimg;
	}
	public void setDistriimg(String distriimg) {
		this.distriimg = distriimg;
	}
	
}
