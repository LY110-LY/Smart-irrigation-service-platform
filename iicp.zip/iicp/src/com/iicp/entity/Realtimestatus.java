package com.iicp.entity;

public class Realtimestatus {

	private int ID,locklimit,dam_state,motor_state,opcode;
	private double opening,flow,upstream,downstream;
	
	public Realtimestatus() {
		super();
	}

	public Realtimestatus(int iD, int locklimit, int damState, int motorState,
			int opcode, double opening, double flow, double upstream,
			double downstream) {
		super();
		ID = iD;
		this.locklimit = locklimit;
		dam_state = damState;
		motor_state = motorState;
		this.opcode = opcode;
		this.opening = opening;
		this.flow = flow;
		this.upstream = upstream;
		this.downstream = downstream;
	}
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getLocklimit() {
		return locklimit;
	}
	public void setLocklimit(int locklimit) {
		this.locklimit = locklimit;
	}
	public int getDam_state() {
		return dam_state;
	}
	public void setDam_state(int damState) {
		dam_state = damState;
	}
	public int getMotor_state() {
		return motor_state;
	}
	public void setMotor_state(int motorState) {
		motor_state = motorState;
	}
	public int getOpcode() {
		return opcode;
	}
	public void setOpcode(int opcode) {
		this.opcode = opcode;
	}
	public double getOpening() {
		return opening;
	}
	public void setOpening(double opening) {
		this.opening = opening;
	}
	public double getFlow() {
		return flow;
	}
	public void setFlow(double flow) {
		this.flow = flow;
	}
	public double getUpstream() {
		return upstream;
	}
	public void setUpstream(double upstream) {
		this.upstream = upstream;
	}
	public double getDownstream() {
		return downstream;
	}
	public void setDownstream(double downstream) {
		this.downstream = downstream;
	}
	
}
