package com.iicp.entity;

public class Operatelog {
	
	private int opcode;
	private String username,operatetime,ipaddr;
	
	public Operatelog() {}

	public Operatelog(int opcode, String username, String operatetime,
			String ipaddr) {
		super();
		this.opcode = opcode;
		this.username = username;
		this.operatetime = operatetime;
		this.ipaddr = ipaddr;
	}
	
	public int getOpcode() {
		return opcode;
	}
	public void setOpcode(int opcode) {
		this.opcode = opcode;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getOperatetime() {
		return operatetime;
	}
	public void setOperatetime(String operatetime) {
		this.operatetime = operatetime;
	}
	public String getIpaddr() {
		return ipaddr;
	}
	public void setIpaddr(String ipaddr) {
		this.ipaddr = ipaddr;
	}
	
}
