package com.iicp.entity;

public class Mito {
	
	private int ID,sluiceid;
	private String fullname,area,croptype,place,tel;
	
	public Mito(){};
	
	public Mito(String fullname, String area, String croptype, String place,
			int sluiceid, String tel) {
		super();
		this.fullname = fullname;
		this.area = area;
		this.croptype = croptype;
		this.place = place;
		this.sluiceid = sluiceid;
		this.tel = tel;
	}

	public Mito(int iD, String fullname, String area, String croptype,
			String place, int sluiceid, String tel) {
		super();
		ID = iD;
		this.fullname = fullname;
		this.area = area;
		this.croptype = croptype;
		this.place = place;
		this.sluiceid = sluiceid;
		this.tel = tel;
	}
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCroptype() {
		return croptype;
	}
	public void setCroptype(String croptype) {
		this.croptype = croptype;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public int getSluiceid() {
		return sluiceid;
	}
	public void setSluiceid(int sluiceid) {
		this.sluiceid = sluiceid;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	
}
