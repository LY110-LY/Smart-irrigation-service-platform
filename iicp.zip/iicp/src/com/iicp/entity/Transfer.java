package com.iicp.entity;

public class Transfer {

	private int ID,sluiceid;
	private String mitoname,starttime,endtime,howlong,completion,datatime,sysuser;
	private double orderwater,actualwater;
	
	public Transfer() {
		super();
	}

	public Transfer(int sluiceid, String mitoname, String starttime,
			String endtime, String howlong, String completion, String datatime,
			String sysuser, double orderwater, double actualwater) {
		super();
		this.sluiceid = sluiceid;
		this.mitoname = mitoname;
		this.starttime = starttime;
		this.endtime = endtime;
		this.howlong = howlong;
		this.completion = completion;
		this.datatime = datatime;
		this.sysuser = sysuser;
		this.orderwater = orderwater;
		this.actualwater = actualwater;
	}
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getSluiceid() {
		return sluiceid;
	}
	public void setSluiceid(int sluiceid) {
		this.sluiceid = sluiceid;
	}
	public String getMitoname() {
		return mitoname;
	}
	public void setMitoname(String mitoname) {
		this.mitoname = mitoname;
	}
	public String getStarttime() {
		return starttime;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	public String getHowlong() {
		return howlong;
	}
	public void setHowlong(String howlong) {
		this.howlong = howlong;
	}
	public String getCompletion() {
		return completion;
	}
	public void setCompletion(String completion) {
		this.completion = completion;
	}
	public String getDatatime() {
		return datatime;
	}
	public void setDatatime(String datatime) {
		this.datatime = datatime;
	}
	public String getSysuser() {
		return sysuser;
	}
	public void setSysuser(String sysuser) {
		this.sysuser = sysuser;
	}
	public double getOrderwater() {
		return orderwater;
	}
	public void setOrderwater(double orderwater) {
		this.orderwater = orderwater;
	}
	public double getActualwater() {
		return actualwater;
	}
	public void setActualwater(double actualwater) {
		this.actualwater = actualwater;
	}
	
}
