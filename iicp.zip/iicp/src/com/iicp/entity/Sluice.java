package com.iicp.entity;

public class Sluice {

	private int ID,irrid;
	private String sluicename,remarks;
	private double width,height;
	
	public Sluice() {
		super();
	}

	public Sluice(int irrid, String sluicename, double width,
			double height, String remarks) {
		super();
		this.irrid = irrid;
		this.sluicename = sluicename;
		this.width = width;
		this.height = height;
		this.remarks = remarks;
	}
	
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getIrrid() {
		return irrid;
	}
	public void setIrrid(int irrid) {
		this.irrid = irrid;
	}
	public String getSluicename() {
		return sluicename;
	}
	public void setSluicename(String sluicename) {
		this.sluicename = sluicename;
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}
