package com.iicp.service;

import java.util.List;

import com.iicp.dao.OperatelogDao;
import com.iicp.entity.Operatelog;

public class OperatelogService {

	OperatelogDao operatelogDao = new OperatelogDao();
	
	/**
	 * ��ѯ��������
	 * @return List<Operatelog>
	 */
	public List<Operatelog> getAll(){
		return operatelogDao.selectAll();
	}
	
}
