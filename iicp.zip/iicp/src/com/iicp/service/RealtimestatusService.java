package com.iicp.service;

import java.util.List;

import com.iicp.dao.RealtimestatusDao;
import com.iicp.entity.Realtimestatus;

public class RealtimestatusService {

	RealtimestatusDao realtimestatusDao = new RealtimestatusDao();
	
	/**
	 * ��ѯ��������
	 * @return List<Realtimestatus>
	 */
	public List<Realtimestatus> getAll(){
		return realtimestatusDao.selectAll();
	}
	
	/**
	 * ͨ��ID��ѯ��������
	 * @param ID
	 * @return List<Realtimestatus>
	 */
	public List<Realtimestatus> getAll(int ID){
		return realtimestatusDao.selectAllByID(ID);
	}
	
	/**
	 * ��ѯբվ����
	 * @return int
	 */
	public int getSluiceNumber(){
		return realtimestatusDao.selectSluiceNumber();
	}
	
	/**
	 * ��ѯ���е��״̬
	 * @return List<Integer>
	 */
	public List<Integer> getAllMotorState(){
		return realtimestatusDao.selectAllMotorState();
	}
	
}
