package com.iicp.service;

import java.util.List;

import com.iicp.dao.UsersDao;
import com.iicp.entity.Users;

public class UsersService {

	UsersDao usersDao = new UsersDao();
	
	/**
	 * ͨ��username��ѯusername,fullname,department,tel,email
	 * @param username
	 * @return Users(username,fullname,department,tel,email)
	 */
	public Users getByUsername(String username){
		return usersDao.selectUsersInfomationByUsername(username);
	}
	
	/**
	 * ͨ��username�޸�password
	 * @param username
	 * @param password
	 */
	public void updatePassword(String username,String password){
		usersDao.updatePasswordByUsername(username, password);
	}
	
	/**
	 * ��ѯ�û������Ƿ���ȷ
	 * @param username
	 * @param password
	 * @return
	 */
	public boolean isLogin(Users user){
		Users realuser = usersDao.selectPasswordByUsername(user.getUsername());
		if(realuser!=null){
			if(realuser.getPassword().equals(user.getPassword())){
				return true;
			}
		}
		return false;
	}
	
	/**
	 * ��ȡ��������
	 * @return
	 */
	public List<Users> getAll(){
		return usersDao.selectAll();
	}
	
	/**
	 * ����һ����¼
	 * @param user
	 * @param id
	 * @return
	 */
	public int update(Users user,int id){
		return usersDao.updateById(user, id);
	}

	/**
	 * ɾ��һ����¼
	 * @param id
	 * @return
	 */
	public int delete(int id){
		return usersDao.deleteById(id);
	}
	
	/**
	 * ����һ����¼
	 * @param user
	 * @return
	 */
	public int add(Users user){
		return usersDao.insertUsers(user);
	}
}
