package com.iicp.service;

import java.util.List;

import com.iicp.dao.TransferDao;
import com.iicp.entity.Transfer;

public class TransferService {

	TransferDao transferDao = new TransferDao();
	
	/**
	 * ��ѯ��������
	 * @return List<Transfer>
	 */
	public List<Transfer> getAll(){
		return transferDao.selectAll();
	}
	
	/**
	 * ����һ������
	 * @param transfer
	 * @return int
	 */
	public int add(Transfer transfer){
		return transferDao.insertTransfer(transfer);
	}
	
	/**
	 * ͨ��IDɾ������
	 * @param ID
	 */
	public int remove(int ID){
		return transferDao.deleteByID(ID);
	}
	
	/**
	 * ͨ��ID���¼�¼
	 * @param transfer
	 */
	public int update(Transfer transfer,int ID){
		return transferDao.updateByID(transfer,ID);
	}
	
	/**
	 * ��ѯ����ļ�¼����
	 * @return int
	 */
	public int getInDay(){
		return transferDao.selectTransferByDay();
	}
	
	/**
	 * ��ѯ���¼�¼
	 * @return List<Transfer>
	 */
	public List<Transfer> getInMonth(){
		return transferDao.selectAllInTheMonth();
	}
	
}
