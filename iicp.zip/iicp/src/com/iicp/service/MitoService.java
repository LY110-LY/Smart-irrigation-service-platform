package com.iicp.service;

import java.util.List;

import com.iicp.dao.MitoDao;
import com.iicp.entity.Mito;

public class MitoService {
	
	MitoDao mitoDao = new MitoDao();
	
	/**
	 * ��ѯ��������
	 * @return List<Mito>
	 */
	public List<Mito> getAll(){
		return mitoDao.selectAll();
	}
	
	/**
	 * ����һ��MitoDao��¼
	 * @param mito
	 * @return int
	 */
	public int add(Mito mito){
		return mitoDao.insertMito(mito);
	}
	
	/**
	 * ͨ��IDɾ��
	 * @param ID
	 */
	public int delete(int ID){
		return mitoDao.deleteMito(ID);
	}
	
	/**
	 * ͨ��ID������Ϣ
	 * @param mito
	 */
	public int update(Mito mito,int ID){
		return mitoDao.updateMito(mito,ID);
	}
	
	/**
	 * ��ѯ���м�¼����
	 * @return int
	 */
	public int getSize(){
		return mitoDao.selectMitoNumber();
	}
	
}
