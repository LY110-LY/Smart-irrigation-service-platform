package com.iicp.service;

import com.iicp.dao.WebbufferDao;
import com.iicp.entity.Webbuffer;

public class WebbufferService {

	WebbufferDao webbufferDao = new WebbufferDao();
	
	/**
	 * ����һ��webbuffer��¼
	 * @param webbuffer
	 * @return int
	 */
	public int add(Webbuffer webbuffer){
		return webbufferDao.insertWebbuffer(webbuffer);
	}
	
}
